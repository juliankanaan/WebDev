
<footer class="footer">
<button onclick="back();" class="btn btn-secondary">Previous page</button>
</footer>
<script>
function back(){
  window.history.back();
}
</script>
