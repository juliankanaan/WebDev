<?php
$my_str = 'The quick brown fox jumps over the lazy dog.';
 
// Outputs: 9
echo str_word_count($my_str);
?>