<?php

// double quotes allow special characters

$newline = 'A newline is \n';
$return = 'A carriage return is \r';
$tab = 'A tab is \t';
$dollar = 'A dollar sign is \$';
$doublequote = 'A double-quote is \"';

echo $newline;
echo $return;
echo $tab;
echo $dollar;
echo $doublequote;

?>